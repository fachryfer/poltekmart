<li><a href="{{route('userpanel.index')}}">Profil Saya</a></li>
<li><a href="{{route('profile.show')}}">Detail Profil</a></li>
<li><a href="{{route('userpanel.reviews')}}">Ulasan dan Tinjauan Saya</a></li>
<li><a href="{{route('shopcart.index')}}">Keranjang Saya</a></li>
<li><a href="{{route('userpanel.orders')}}">Histori Pemesanan Saya</a></li>
<li><a href="{{route('userpanel.favoriteproduct')}}">Produk Favorit Saya</a></li>
