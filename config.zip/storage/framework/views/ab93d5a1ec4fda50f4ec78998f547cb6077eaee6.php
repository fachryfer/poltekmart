

<?php $__env->startSection('title', 'Ulasan dan Tinjauan Saya'); ?>
<?php $__env->startSection('description', optional($setting)->description); ?>
<?php $__env->startSection('keywords', optional($setting)->keywords); ?>
<?php $__env->startSection('icon', Storage::url(optional($setting)->icon)); ?>

<?php $__env->startSection('content'); ?>
<!-- Bagian Mulai Breadcrumb -->
<section class="breadcrumb-section set-bg" data-setbg="<?php echo e(asset('assets')); ?>/img/colorcard.png">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2>Akun Saya</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Bagian Selesai Breadcrumb -->

<!-- Bagian Mulai Blog -->
<section class="blog spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-5">
                <div class="blog__sidebar">
                    <div class="blog__sidebar__item">
                        <h4>Aktivitas Saya</h4>
                        <ul>
                            <?php echo $__env->make('home.user.usermenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-9 col-md-9 col-sm-9">
                <h4 class="text-center">Ulasan dan Tinjauan Saya</h4> <br>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>
                                Id
                            </th>
                            <th>
                                Produk
                            </th>
                            <th>
                                Judul
                            </th>
                            <th>
                                Ulasan
                            </th>
                            <th>
                                Penilaian
                                <br>(Dari 5)
                            </th>
                            <th>
                                Status
                            </th>
                            <th>
                                Hapus
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($rs->id); ?></td>
                            <td><a href="<?php echo e(route('product',['id'=>$rs->product_id])); ?>"><?php echo e($rs->product->title); ?></a></td>
                            <td><?php echo e($rs->subject); ?></td>
                            <td><?php echo e($rs->comment); ?></td>
                            <td><?php echo e($rs->rate); ?></td>
                            <td><?php echo e($rs->status); ?></td>
                            <td>
                                <a href="<?php echo e(route('userpanel.reviewdestroy',['id'=>$rs->id])); ?>" class="btn btn-block btn-danger btn-sm" onclick="return confirm('Dihapus, Apakah Anda yakin ?')">Hapus</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelMarket\PoltekMart\resources\views/home/user/comments.blade.php ENDPATH**/ ?>