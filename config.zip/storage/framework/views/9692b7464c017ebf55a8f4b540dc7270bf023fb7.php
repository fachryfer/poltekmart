

<?php $__env->startSection('title', 'Detail Produk'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content-inner">
    <!-- area baris dimulai -->
    <div class="row">
        <div class="col-lg-12 col-ml-12">
            <div class="row">
                <!-- mulai formulir tabel -->
                <div class="col-lg-12 mt-5">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">Detail Pesan</h4>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <tr>
                                            <th style="width: 30px">Id</th>
                                            <td><?php echo e($data->id); ?></td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Nama</th>
                                            <td><?php echo e($data->name); ?></td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Email</th>
                                            <td><?php echo e($data->email); ?></td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Telepon</th>
                                            <td><?php echo e($data->phone); ?></td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Subjek</th>
                                            <td><?php echo e($data->subject); ?></td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Pesan</th>
                                            <td><?php echo e($data->message); ?></td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Perbarui Status:</th>
                                            <td>
                                                <form role="form" action="<?php echo e(route('admin.message.update',['id'=>$data->id])); ?>" method="POST" class="forms-sample">
                                                    <?php echo csrf_field(); ?>
                                                    <select name="status" id="">
                                                        <option selected><?php echo e($data->status); ?></option>
                                                        <option>Baru</option>
                                                        <option>Dibaca</option>
                                                    </select>
                                                    <div class="card-footer">
                                                        <button type="submit" class="btn-primary">Perbarui Status</button>
                                                    </div>
                                                </form>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Tanggal Dibuat</th>
                                            <td><?php echo e($data->created_at); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Tanggal Terakhir Diperbarui</th>
                                            <td><?php echo e($data->updated_at); ?></td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Catatan Admin:</th>
                                            <td>
                                                <form role="form" action="<?php echo e(route('admin.message.update',['id'=>$data->id])); ?>" method="POST" class="forms-sample">
                                                    <?php echo csrf_field(); ?>
                                                    <textarea cols="80" class="textarea" name="note" id="note">
                                                        <?php echo e($data->note); ?>

                                                    </textarea>
                                                    <div class="card-footer">
                                                        <button type="submit" class="btn-primary">Tambahkan Catatan</button>
                                                    </div>
                                                </form>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- formulir tabel berakhir -->
            </div>
        </div>
    </div>
    <!-- area baris berakhir -->
    <div class="row mt-5">
    </div>
    <!-- area baris dimulai -->
</div>
</div>
<!-- area konten utama berakhir -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelMarket\PoltekMart\resources\views/admin/message/show.blade.php ENDPATH**/ ?>