<li><a href="<?php echo e(route('userpanel.index')); ?>">Profil Saya</a></li>
<li><a href="<?php echo e(route('profile.show')); ?>">Detail Profil</a></li>
<li><a href="<?php echo e(route('userpanel.reviews')); ?>">Ulasan dan Tinjauan Saya</a></li>
<li><a href="<?php echo e(route('shopcart.index')); ?>">Keranjang Saya</a></li>
<li><a href="<?php echo e(route('userpanel.orders')); ?>">Histori Pemesanan Saya</a></li>
<li><a href="<?php echo e(route('userpanel.favoriteproduct')); ?>">Produk Favorit Saya</a></li>
<?php /**PATH C:\PoltekMart\resources\views/home/user/usermenu.blade.php ENDPATH**/ ?>