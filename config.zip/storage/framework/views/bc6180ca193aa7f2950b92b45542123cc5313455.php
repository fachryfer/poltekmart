

<?php $__env->startSection('title', 'Panel Admin İz Market'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content-inner">
        <!-- Mulai daerah baris -->
        <div class="row">
            <div class="col-lg-12 col-ml-12">
                <div class="row">
                    <!-- Mulai formulir tabel -->
                    <div class="col-12 mt-5">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="header-title">Edit Kategori</h4>
                                <form role="form" action="<?php echo e(route('admin.category.update',['id'=>$data->id])); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="">Kategori Induk</label>
                                        <select name="parent_id" class="form-control select2">
                                            <option value="0" selected="selected"></option>
                                            <?php $__currentLoopData = $datalist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($rs->id); ?>"> <?php echo e(\App\Http\Controllers\AdminPanel\CategoryController::getParentsTree($rs, $rs->title)); ?> </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputName1">Judul</label>
                                        <input type="text" class="form-control" id="exampleInputName1" value="<?php echo e($data->title); ?>" name="title">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputName1">Kata Kunci</label>
                                        <input type="text" class="form-control" id="exampleInputName1" value="<?php echo e($data->keywords); ?>" name="keywords">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputName1">Deskripsi</label>
                                        <input type="Description" class="form-control" id="exampleInputName1" value="<?php echo e($data->description); ?>" name="description">
                                    </div>
                                    <div class="form-group">
                                        <label>Unggah Foto</label>
                                        <div class="input-group col-xs-12">
                                            <label for="formFile" class="form-label"></label>
                                            <input class="form-control" type="file" name="image" id="image">
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-warning me-2">Update Informasi</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- Akhir formulir tabel -->
                </div>
            </div>
        </div>
        <!-- Akhir daerah baris -->
        <div class="row mt-5">
        </div>
        <!-- Mulai daerah baris -->
    </div>
</div>
<!-- Akhir daerah konten utama -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelMarket\PoltekMart\resources\views/admin/category/edit.blade.php ENDPATH**/ ?>