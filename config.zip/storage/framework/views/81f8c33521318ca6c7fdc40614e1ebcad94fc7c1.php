

<?php $__env->startSection('title', 'İz Market Ürünler'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content-inner">
    <!-- Memulai area baris -->
    <div class="row">
        <div class="col-lg-12 col-ml-12">
            <div class="row">
                <!-- Memulai formulir tabel -->
                <div class="col-lg-12 mt-5">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">Pesan</h4>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table class="table text-center">
                                        <thead class="text-uppercase bg-warning">
                                            <tr class="text-white">
                                                <th scope="col">ID</th>
                                                <th scope="col">Nama</th>
                                                <th scope="col">Telepon</th>
                                                <th scope="col">Surel</th>
                                                <th scope="col">Subyek</th>
                                                <th scope="col">Status</th>
                                                <th scope="col">Tampilkan Detail</th>
                                                <th scope="col">Hapus</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($rs->id); ?></th>
                                                <td><?php echo e($rs->name); ?></td>
                                                <td><?php echo e($rs->email); ?></td>
                                                <td><?php echo e($rs->phone); ?></td>
                                                <td><?php echo e($rs->subject); ?></td>
                                                <td><?php echo e($rs->status); ?></td>
                                                <td><a class="ti-info-alt" href="<?php echo e(route('admin.message.show',['id'=>$rs->id])); ?>"></a></td>
                                                <td><a class="ti-trash" href="<?php echo e(route('admin.message.destroy',['id'=>$rs->id])); ?>" , onclick="return confirm('Apakah Anda yakin ingin menghapus?')"></a></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Akhir formulir tabel -->
            </div>
        </div>
    </div>
    <!-- Akhir area baris -->
    <div class="row mt-5">
    </div>
    <!-- Mulai area baris -->
</div>
</div>
<!-- Akhir area konten utama -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelMarket\PoltekMart\resources\views/admin/message/index.blade.php ENDPATH**/ ?>