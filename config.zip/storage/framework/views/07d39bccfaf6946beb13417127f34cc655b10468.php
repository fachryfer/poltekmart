

<?php $__env->startSection('title', optional($setting)->title); ?>
<?php $__env->startSection('description', optional($setting)->description); ?>
<?php $__env->startSection('keywords', optional($setting)->keywords); ?>
<?php $__env->startSection('icon', Storage::url(optional($setting)->icon)); ?>

<?php $__env->startSection('content'); ?>
<!-- Bagian Hero Dimulai -->
<section class="hero">
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="hero__categories category__menu">
                    <?php
                    $mainCategories = \App\Http\Controllers\HomeController::maincategorylist();
                    ?>
                    <div class="hero__categories__all">
                        <i class="fa fa-bars"></i>
                        <span>Kategori</span>
                    </div>
                    <ul>
                        <?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class=""><a href="<?php echo e(route('categoryproducts',['id'=>$rs->id])); ?>"><?php echo e($rs->title); ?></a>
                            <?php if(count($rs->children)): ?>
                            <?php echo $__env->make('home.categorytree',['children' => $rs->children], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-lg-9">
                <div class="hero__search">
                    <div class="hero__search__form">
                        <form action="<?php echo e(route('getproduct')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search')->html();
} elseif ($_instance->childHasBeenRendered('Y9QXKum')) {
    $componentId = $_instance->getRenderedChildComponentId('Y9QXKum');
    $componentTag = $_instance->getRenderedChildComponentTagName('Y9QXKum');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Y9QXKum');
} else {
    $response = \Livewire\Livewire::mount('search');
    $html = $response->html();
    $_instance->logRenderedChild('Y9QXKum', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            <button type="submit" class="site-btn">CARI</button>
                        </form>
                        <?php echo \Livewire\Livewire::scripts(); ?>

                    </div>
                    <div class="hero__search__phone">
                        
                    </div>
                </div>
                <div class="hero__item set-bg" data-setbg="<?php echo e(asset('assets')); ?>/img/hero/banner2.jpg">
                    <div class="hero__text">
                        <span>Belanja Hemat</span>
                        <h2>Produk Terbaik <br />dengan Harga Terjangkau</h2>
                        <a href="productcategory/1" class="primary-btn">Belanja</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Bagian Hero Selesai -->

<!-- Bagian Kategori Dimulai -->
<section class="categories">
    <div class="container">
        <div class="row">
            <div class="categories__slider owl-carousel">
                <?php $__currentLoopData = $sliderdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3">
                    <div class="categories__item set-bg" data-setbg="<?php echo e(Storage::url("{$rs->image}")); ?>">
                        <h5 style="background-color: white;"><a href="<?php echo e(route('categoryproducts',['id'=>$rs->id])); ?>"><?php echo e($rs->title); ?></a></h5>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<!-- Bagian Kategori Selesai -->

<!-- Bagian Produk Unggulan Dimulai -->
<section class="featured spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title">
                    <h2>Produk Relevan</h2>
                </div>
            </div>
        </div>
        <?php echo $__env->make('home.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row featured__filter">
            <?php $__currentLoopData = $servicelist1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-2 col-md-4 col-sm-6 mix oranges fresh-meat">
                <div class="featured__item">
                    <div class="featured__item__pic set-bg" data-setbg="<?php echo e(Storage::url("{$rs->image}")); ?>">
                        <ul class="featured__item__pic__hover">
                            <li><a href="<?php echo e(route('storefavorite',['id'=>$rs->id])); ?>"><i class="fa fa-heart"></i></a></li>
                            <li><a href="<?php echo e(route('shopcart.add',['id'=>$rs->id])); ?>"><i class="fa fa-shopping-cart"></i></a></li>
                        </ul>
                    </div>
                    <div class="featured__item__text">
                        <h6><a href="<?php echo e(route('product',['id'=>$rs->id])); ?>"><?php echo e($rs->title); ?></a></h6>
                        <h5>Rp. <?php echo e(number_format($rs->price, 2)); ?></h5>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!-- Bagian Produk Unggulan Selesai -->

<!-- Bagian Banner Dimulai -->
<div class="banner">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="banner__pic">
                    <img src="<?php echo e(asset('assets')); ?>/img/banner/bannerwin.jpg" alt="">
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="banner__pic">
                    <img src="<?php echo e(asset('assets')); ?>/img/banner/bannerwin2.jpg" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Bagian Banner Selesai -->

<!-- Bagian Produk Terbaru Dimulai -->
<section class="latest-product spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="latest-product__text">
                    <h4>Produk Terbaru</h4>
                    <div class="latest-product__slider owl-carousel">
                        <?php $__currentLoopData = $lastproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="latest-prdouct__slider__item">
                            <a href="<?php echo e(route('product',['id'=>$rs->id])); ?>" class="latest-product__item">
                                <div class="latest-product__item__pic">
                                    <img src="<?php echo e(Storage::url("{$rs->image}")); ?>" />
                                </div>
                                <div class="latest-product__item__text">
                                    <h6><?php echo e($rs->title); ?></h6>
                                    <span>Rp. <?php echo e(number_format($rs->price, 2)); ?></span>
                                </div>
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="latest-product__text">
                    <h4>Produk Terlaris</h4>
                    <div class="latest-product__slider owl-carousel">
                        <?php $__currentLoopData = $mostsellerproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="latest-prdouct__slider__item">
                            <a href="<?php echo e(route('product',['id'=>$rs->product->id])); ?>" class="latest-product__item">
                                <div class="latest-product__item__pic">
                                    <img src="<?php echo e(Storage::url($rs->product->image)); ?>" alt="">
                                </div>
                                <div class="latest-product__item__text">
                                    <h6><?php echo e($rs->product->title); ?></h6>
                                    <span>Rp. <?php echo e(number_format($rs->product->price, 2)); ?></span>
                                </div>
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="latest-product__text">
                    <h4>Produk Dengan Penilaian Tertinggi</h4>
                    <div class="latest-product__slider owl-carousel">
                        <?php $__currentLoopData = $mosthasreviewproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($rs->product): ?>
                                <div class="latest-prdouct__slider__item">
                                    <a href="<?php echo e(route('product', ['id' => $rs->product->id])); ?>" class="latest-product__item">
                                        <div class="latest-product__item__pic">
                                            <img src="<?php echo e(Storage::url($rs->product->image)); ?>" alt="">
                                        </div>
                                        <div class="latest-product__item__text">
                                            <h6><?php echo e($rs->product->title); ?></h6>
                                            <span>Rp. <?php echo e(number_format($rs->product->price, 2)); ?></span>
                                        </div>
                                    </a>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>            
        </div>
    </div>
</section>
<!-- Bagian Produk Terbaru Selesai -->

<!-- Bagian Blog Dimulai -->
<section class="from-blog spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title from-blog__title">
                    <h2>Pertanyaan yang Sering Diajukan</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $lastfaqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-4 col-sm-6">
                <div class="blog__item">
                    <div class="blog__item__text">
                        <ul>
                            <li><i class="fa fa-calendar-o"></i> <?php echo e($rs->created_at->format('m/d/Y')); ?></li>
                        </ul>
                        <h5><?php echo e($rs->question); ?></h5>
                        <p><?php echo $rs->answer; ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!-- Bagian Blog Selesai -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PoltekMart\resources\views/home/index.blade.php ENDPATH**/ ?>