

<?php $__env->startSection('title', 'Panel Admin İz Market'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content-inner">
    <!-- Area baris dimulai -->
    <div class="row">
        <div class="col-lg-12 col-ml-12">
            <div class="row">
                <!-- Mulai formulir tabel -->
                <div class="col-lg-12 mt-5">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">Kategori</h4>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table class="table text-center">
                                        <thead class="text-uppercase bg-warning">
                                            <tr class="text-white">
                                                <th scope="col">ID</th>
                                                <th scope="col">Parent Kategori</th>
                                                <th scope="col">Judul</th>
                                                <th scope="col">Kata Kunci</th>
                                                <th scope="col">Deskripsi</th>
                                                <th scope="col">Foto</th>
                                                <th scope="col">Edit</th>
                                                <th scope="col">Tampilkan Detail</th>
                                                <th scope="col">Hapus</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($rs->id); ?></th>
                                                <td><?php echo e(\App\Http\Controllers\AdminPanel\CategoryController::getParentsTree($rs, $rs->title)); ?></td>
                                                <td><?php echo e($rs->title); ?></td>
                                                <td><?php echo e($rs->keywords); ?></td>
                                                <td><?php echo e($rs->description); ?></td>
                                                <td>
                                                <?php if($rs->image): ?>
                                                    <img src="<?php echo e(Storage::url($rs->image)); ?>" style="height:50px ;width:50px; border-radius:2px">
                                                    <?php endif; ?>
                                                </td>
                                                <td><a class="ti-write" href="<?php echo e(route('admin.category.edit',['id'=>$rs->id])); ?>"></a></td>
                                                <td><a class="ti-info-alt" href="<?php echo e(route('admin.category.show',['id'=>$rs->id])); ?>"></a></td>
                                                <td><a class="ti-trash" href="<?php echo e(route('admin.category.delete',['id'=>$rs->id])); ?>", onclick="return confirm('Yakin ingin menghapus ?')"></a></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <a class="btn btn-danger" href="<?php echo e(route('admin.category.create')); ?>">Tambah Kategori Baru</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- formulir tabel berakhir -->
            </div>
        </div>
    </div>
    <!-- Area baris berakhir -->
    <div class="row mt-5">
    </div>
    <!-- Area baris dimulai-->
</div>
</div>
<!-- Area konten utama berakhir -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelMarket\PoltekMart\resources\views/admin/category/index.blade.php ENDPATH**/ ?>