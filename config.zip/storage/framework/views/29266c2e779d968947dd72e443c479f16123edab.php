

<?php $__env->startSection('title', 'Halaman Pesanan'); ?>
<?php $__env->startSection('description', optional($setting)->description); ?>
<?php $__env->startSection('keywords', optional($setting)->keywords); ?>
<?php $__env->startSection('icon', Storage::url(optional($setting)->icon)); ?>

<?php $__env->startSection('content'); ?>
<section class="breadcrumb-section set-bg" data-setbg="<?php echo e(asset('assets')); ?>/img/colorcard.png">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2>Pembayaran</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Bagian Selesai Breadcrumb -->

<!-- Bagian Kontak Mulai -->
<!-- Bagian Checkout Mulai -->
<section class="checkout spad">
    <div class="container">
        <div class="checkout__form">
            <h4>Detail Pesanan</h4>
            <form action="<?php echo e(route('shopcart.storeorder')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="checkout__input">
                                    <p>Nama &amp; Nama Belakang<span>*</span></p>
                                    <input type="text" name="name" placeholder="Nama &amp; Nama Belakang" value="<?php echo e(Auth::user()->name); ?>">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="checkout__input">
                                    <p>Nomor Telepon<span>*</span></p>
                                    <input type="tel" name="phone" placeholder="Nomor Telepon">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="checkout__input">
                                    <p>Alamat Email<span>*</span></p>
                                    <input type="email" name="email" placeholder="Alamat Email" value="<?php echo e(Auth::user()->email); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="checkout__input">
                            <p>Alamat<span>*</span></p>
                            <input type="text" name="address" placeholder="Alamat" class="checkout__input__add">
                        </div>
                        
                        <div class="checkout__input">
                            <input type="hidden" name="total" value="<?php echo e($total); ?>">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="checkout__order">
                            <h4>Pesanan Anda</h4>
                            <div class="checkout__order__products">Produk &amp; Jumlah<span>Harga</span></div>
                            <ul>
                                <?php $__currentLoopData = $datalist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($rs->product->title); ?> x <?php echo e($rs->quantity); ?><span>Rp. <?php echo e(number_format($rs->product->price, 2)); ?></span></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <div class="checkout__order__subtotal">Subtotal <span>Rp.  <?php echo e(number_format($total, 2)); ?></span></div>
                            <div class="checkout__order__total">Total Pesanan <span>Rp.  <?php echo e(number_format($total, 2)); ?></span></div>                          
                            <button type="submit" class="site-btn">SELESAIKAN PESANAN</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>
<!-- Bagian Checkout Selesai -->

<?php if(session('error')): ?>
    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.frontbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelMarket\PoltekMart\resources\views/home/user/order.blade.php ENDPATH**/ ?>