

<?php $__env->startSection('title', 'POLTEKMART | ADMIN PANEL'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content-inner">
    <!-- row area start -->
    <div class="row">
        <div class="col-lg-12 col-ml-12">
            <div class="row">
                <!-- table form start -->
                <div class="col-lg-12 mt-5">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title"><?php echo e($data->name); ?></h4>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <tr>
                                            <th>Id</th>
                                            <td><?php echo e($data->id); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Name</th>
                                            <td><?php echo e($data->name); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Email</th>
                                            <td><?php echo e($data->email); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Roles</th>
                                            <td>
                                                <?php $__currentLoopData = $data->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($role->name); ?>

                                                <a href="<?php echo e(route('admin.user.destroyrole',['uid'=>$data->id,'rid'=>$role->id])); ?>" , onclick="return confirm('Are you sure you want to delete?')">[x]</a>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Created At</th>
                                            <td><?php echo e($data->created_at); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Updated At</th>
                                            <td><?php echo e($data->updated_at); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Add to Role User</th>
                                            <td>
                                                <form role="form" action="<?php echo e(route('admin.user.addrole',['id'=>$data->id])); ?>" method="POST" class="forms-sample">
                                                    <?php echo csrf_field(); ?>
                                                    <select name="role_id">
                                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <div class="card-footer">
                                                        <button type="submit" class="btn-primary">Add Role</button>
                                                    </div>
                                                </form>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- table form end -->
            </div>
        </div>
    </div>
    <!-- row area end -->
    <div class="row mt-5">
    </div>
    <!-- row area start-->
</div>
</div>
<!-- main content area end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PoltekMart\resources\views/admin/user/show.blade.php ENDPATH**/ ?>