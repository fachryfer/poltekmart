

<?php $__env->startSection('title', 'Produk Iz Market'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content-inner">
    <!-- area row start -->
    <div class="row">
        <div class="col-lg-12 col-ml-12">
            <div class="row">
                <!-- start table form -->
                <div class="col-lg-12 mt-5">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">Produk</h4>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table class="table text-center">
                                        <thead class="text-uppercase bg-warning">
                                            <tr class="text-white">
                                                <th scope="col">ID</th>
                                                <th scope="col">Kategori</th>
                                                <th scope="col">Judul</th>
                                                <th scope="col">Foto</th>
                                                <th scope="col">Galeri</th>
                                                <th scope="col">Harga</th>
                                                <th scope="col">Stok</th>
                                                <th scope="col">edit</th>
                                                <th scope="col">lihat detail</th>
                                                <th scope="col">hapus</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($rs->id); ?></th>
                                                <td> <?php echo e(\App\Http\Controllers\AdminPanel\CategoryController::getParentsTree($rs->category, $rs->category->title)); ?></td>
                                                <td><?php echo e($rs->title); ?></td>
                                                <td>
                                                    <?php if($rs->image): ?>
                                                    <img src="<?php echo e(Storage::url($rs->image)); ?>" style="height:50px ;width:50px; border-radius:2px">
                                                    <?php endif; ?>
                                                </td>
                                                <td style="text-align: center">
                                                    <a href="<?php echo e(route('admin.image.index',['sid'=>$rs->id])); ?>" onclick="return !window.open(this.href,'','top=50 left=100 width=1100,height=700')">
                                                        <img src="<?php echo e(asset('assets')); ?>/admin/images/gallery.png" style="height:50px ;width:50px; border-radius:2px">
                                                    </a>
                                                </td>
                                                <td>Rp. <?php echo e($rs->price); ?></td>
                                                <td><?php echo e($rs->quantity); ?></td>
                                                <td><a class="ti-write" href="<?php echo e(route('admin.product.edit',['id'=>$rs->id])); ?>"></a></td>
                                                <td><a class="ti-info-alt" href="<?php echo e(route('admin.product.show',['id'=>$rs->id])); ?>"></a></td>
                                                <td><a class="ti-trash" href="<?php echo e(route('admin.product.delete',['id'=>$rs->id])); ?>" , onclick="return confirm('Apakah Anda yakin ingin menghapus?')"></a></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <a class="btn btn-danger" href="<?php echo e(route('admin.product.create')); ?>">Tambah Produk Baru</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end table form -->
            </div>
        </div>
    </div>
    <!-- end area row -->
    <div class="row mt-5">
    </div>
    <!-- start area row -->
</div>
</div>
<!-- end main content area -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelMarket\POLTEKMART YANG PALING BARU DARI YANG PALING BARU\PoltekMart\resources\views/admin/product/index.blade.php ENDPATH**/ ?>