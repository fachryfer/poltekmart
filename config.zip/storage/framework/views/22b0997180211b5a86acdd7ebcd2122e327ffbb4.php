<div class="hero__search__form">
    <div class="hero__search__categories">
        Semua Kategori
        <span class="arrow_carrot-down"></span>
    </div>
    <input wire:model="search" type="text" name="search" class="input search-input" list="myList" placeholder="Hayoo cari apa hayoo ?" />
    <?php if(!empty($query)): ?>
    <datalist id="myList">
        <?php $__currentLoopData = $datalist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($rs->title); ?>"><?php echo e($rs->category->title); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <datalist />
        <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\LaravelMarket\POLTEKMART YANG PALING BARU DARI YANG PALING BARU\PoltekMart\resources\views/livewire/search.blade.php ENDPATH**/ ?>