<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="<?php echo $__env->yieldContent("description"); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent("keywords"); ?>">
    <meta name="viewport" content="<?php echo $__env->yieldContent("title"); ?>">
    <meta name="author" content="Fachry Ferdiansyah Sembiring">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent("title"); ?></title>
    <link rel="icon" type="image/x-icon" href="<?php echo $__env->yieldContent("icon"); ?>">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;600;900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/style.css" type="text/css">
    <?php echo $__env->yieldContent("head"); ?>
</head>

<body>
<?php echo $__env->make("home.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make("home.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\LaravelMarket\POLTEKMART YANG PALING BARU DARI YANG PALING BARU\PoltekMart\resources\views/layouts/frontbase.blade.php ENDPATH**/ ?>