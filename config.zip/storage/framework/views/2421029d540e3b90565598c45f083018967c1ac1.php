

<?php $__env->startSection('title', 'Produk Iz Market'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content-inner">
    <!-- Memulai area baris -->
    <div class="row">
        <div class="col-lg-12 col-ml-12">
            <div class="row">
                <!-- Memulai formulir tabel -->
                <div class="col-lg-12 mt-5">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title"><?php echo e($product->title); ?></h4>
                            <form role="form" action="<?php echo e(route('admin.image.store',['sid'=>$product->id])); ?>" method="POST" enctype="multipart/form-data" class="forms-sample">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="exampleInputName1">Judul</label>
                                    <input type="text" class="form-control" id="exampleInputName1" placeholder="Judul" name="title">
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlFile1">Unggah Berkas</label>
                                    <input type="file" class="form-control-file" id="exampleFormControlFile1" name="image">
                                </div>
                                <button type="submit" class="btn btn-primary">Unggah</button>
                            </form>
                            <div class="table-responsive pt-4">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>
                                                Id
                                            </th>
                                            <th>
                                                Judul
                                            </th>
                                            <th>
                                                Foto
                                            </th>
                                            <th>
                                                Hapus
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($rs->id); ?></td>
                                            <td><?php echo e($rs->title); ?></td>
                                            <td>
                                                <?php if($rs->image): ?>
                                                <img src="<?php echo e(Storage::url($rs->image)); ?>" style="height:250px ;width:250px; border-radius:2px">
                                                <?php endif; ?>
                                            </td>
                                            <td><a class="btn btn-danger" style="color: white;" href="<?php echo e(route('admin.image.delete',['sid'=>$product->id,'id'=>$rs->id])); ?>" , onclick="return confirm('Yakin ingin menghapus ?')">Hapus</a></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Akhir formulir tabel -->
            </div>
        </div>
    </div>
    <!-- Akhir area baris -->
    <div class="row mt-5">
    </div>
    <!-- Memulai area baris -->
</div>
</div>
<!-- Akhir area konten utama -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PoltekMart\resources\views/admin/image/index.blade.php ENDPATH**/ ?>