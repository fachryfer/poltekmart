

<?php $__env->startSection('title', 'İz Market Products'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content-inner">
    <!-- row area start -->
    <div class="row">
        <div class="col-lg-12 col-ml-12">
            <div class="row">
                <!-- table form start -->
                <div class="col-lg-12 mt-5">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">Products</h4>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table class="table text-center">
                                        <thead class="text-uppercase bg-warning">
                                            <tr class="text-white">
                                                <th scope="col">ID</th>
                                                <th scope="col">Question</th>
                                                <th scope="col">Answer</th>
                                                <th scope="col">Edit</th>
                                                <th scope="col">Delete</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($rs->id); ?></th>
                                                <td><?php echo e($rs->question); ?></td>
                                                <td><?php echo $rs->answer; ?></td>
                                                <td><a class="ti-write" href="<?php echo e(route('admin.faq.edit',['id'=>$rs->id])); ?>"></a></td>
                                                <td><a class="ti-trash" href="<?php echo e(route('admin.faq.destroy',['id'=>$rs->id])); ?>" , onclick="return confirm('Are you sure you want to delete?')"></a></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <a class="btn btn-danger" href="<?php echo e(route('admin.faq.create')); ?>">Add New FAQ</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- table form end -->
            </div>
        </div>
    </div>
    <!-- row area end -->
    <div class="row mt-5">
    </div>
    <!-- row area start-->
</div>
</div>
<!-- main content area end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelMarket\PoltekMart\resources\views/admin/faq/index.blade.php ENDPATH**/ ?>