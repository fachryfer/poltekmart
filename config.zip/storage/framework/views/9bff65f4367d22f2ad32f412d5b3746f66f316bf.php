

<?php $__env->startSection('title', 'Pesanan Iz Market'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content-inner">
    <!-- area row start -->
    <div class="row">
        <div class="col-lg-12 col-ml-12">
            <div class="row">
                <!-- start table form -->
                <div class="col-lg-12 mt-5">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title text-warning">Pesanan</h4>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table class="table table-hover text-center">
                                        <thead class="bg-warning text-white">
                                            <tr>
                                                <th scope="col">No</th>
                                                <th scope="col">Nama</th>
                                                <th scope="col">Telepon</th>
                                                <th scope="col">E-mail</th>
                                                <th scope="col">Alamat</th>
                                                <th scope="col">Catatan</th>
                                                <th scope="col">Status</th>
                                                <th scope="col">Pembayaran</th>
                                                <th scope="col">Detail</th>
                                                <th scope="col">Tolak</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $no = ($data->currentPage() - 1) * $data->perPage() + 1; ?>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($no++); ?></th>
                                                <td><a href="<?php echo e(route('admin.user.show',['id'=>$rs->user_id])); ?>"><?php echo e($rs->user->name); ?></a></td>
                                                <td><?php echo e($rs->phone); ?></td>
                                                <td><?php echo e($rs->email); ?></td>
                                                <td><?php echo e($rs->address); ?></td>
                                                <td><?php echo e($rs->note); ?></td>
                                                <td><?php echo e($rs->status); ?></td>
                                                <td><?php echo e($rs->pembayaran); ?></td>
                                                <td><a class="btn btn-sm btn-info" href="<?php echo e(route('admin.order.show',['id'=>$rs->id])); ?>"><i class="ti-info-alt"></i></a></td>
                                                <td><a class="btn btn-sm btn-danger" href="<?php echo e(route('admin.order.reject',['id'=>$rs->id])); ?>" onclick="return confirm('Anda yakin ingin membatalkan pesanan ini?')"><i class="ti-close"></i></a></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <!-- Menampilkan link paginasi -->
                                    <div class="pagination justify-content-center mt-4">
                                        <?php echo e($data->links('vendor.pagination.custom')); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end table form -->
            </div>
        </div>
    </div>
    <!-- end area row -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PoltekMart\resources\views/admin/order/index.blade.php ENDPATH**/ ?>