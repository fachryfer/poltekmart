

<?php $__env->startSection('title', 'Ulasan dan Tinjauan Saya'); ?>
<?php $__env->startSection('description', optional($setting)->description); ?>
<?php $__env->startSection('keywords', optional($setting)->keywords); ?>
<?php $__env->startSection('icon', Storage::url(optional($setting)->icon)); ?>

<?php $__env->startSection('content'); ?>
<!-- Bagian Breadcrumb Mulai -->
<section class="breadcrumb-section set-bg" data-setbg="<?php echo e(asset('assets')); ?>/img/colorcard.png">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2>Akun Saya</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Bagian Breadcrumb Selesai -->
<!-- Bagian Blog Mulai -->
<section class="blog spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-5">
                <div class="blog__sidebar">
                    <div class="blog__sidebar__item">
                        <h4>Aktivitas Saya</h4>
                        <ul>
                            <?php echo $__env->make('home.user.usermenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-9 col-md-9 col-sm-9">
                <h4 class="text-center">Ulasan dan Tinjauan Saya</h4> <br>
                <div class="row">
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-12 mb-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Produk: <a href="<?php echo e(route('product',['id'=>$rs->product_id])); ?>"><?php echo e($rs->product->title); ?></a></h5>
                                <p class="card-text"><strong>Judul:</strong> <?php echo e($rs->subject); ?></p>
                                <p class="card-text"><strong>Ulasan:</strong> <?php echo e($rs->comment); ?></p>
                                <p class="card-text"><strong>Penilaian:</strong> <?php echo e($rs->rate); ?>/5</p>
                                <p class="card-text"><strong>Status:</strong> <?php echo e($rs->status); ?></p>
                                <a href="<?php echo e(route('userpanel.reviewdestroy',['id'=>$rs->id])); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Dihapus, Apakah Anda yakin ?')">Hapus</a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Bagian Blog Selesai -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PoltekMart\resources\views/home/user/comments.blade.php ENDPATH**/ ?>