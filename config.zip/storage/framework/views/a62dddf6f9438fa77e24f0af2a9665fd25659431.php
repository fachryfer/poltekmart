

<?php $__env->startSection('title', 'Detail Pesanan Terdahulu'); ?>
<?php $__env->startSection('description', optional($setting)->description); ?>
<?php $__env->startSection('keywords', optional($setting)->keywords); ?>
<?php $__env->startSection('icon', Storage::url(optional($setting)->icon)); ?>

<?php $__env->startSection('content'); ?>
<!-- Bagian Breadcrumb Mulai -->
<section class="breadcrumb-section set-bg" data-setbg="<?php echo e(asset('assets')); ?>/img/colorcard.png">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2>Akun Saya</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Bagian Breadcrumb Selesai -->
<!-- Bagian Blog Mulai -->
<section class="blog spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-5">
                <div class="blog__sidebar">
                    <div class="blog__sidebar__item">
                        <h4>Aktivitas Saya</h4>
                        <ul>
                            <?php echo $__env->make('home.user.usermenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-9 col-md-9 col-sm-9">
                <h4 class="text-center">Detail Pesanan</h4> <br>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID Pesanan</th>
                            <td><?php echo e($order->id); ?></td>
                        </tr>
                        <tr>
                            <th>Nama</th>
                            <td><?php echo e($order->name); ?></td>
                        </tr>
                        <tr>
                            <th>Telepon</th>
                            <td><?php echo e($order->phone); ?></td>
                        </tr>
                        <tr>
                            <th>Alamat</th>
                            <td><?php echo e($order->address); ?></td>
                        </tr>
                        <tr>
                            <th>Catatan</th>
                            <td><?php echo e($order->note); ?></td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td><?php echo e($order->status); ?></td>
                        </tr>
                        <tr>
                            <th>Pembayaran</th>
                            <td><?php echo e($order->pembayaran); ?></td>
                        </tr>
                        <tr>
                            <th>Tanggal Pembuatan Pesanan</th>
                            <td><?php echo e($order->created_at); ?></td>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
                <table class="table text-center">
                    <thead class="text-uppercase bg-warning">
                        <tr class="text-white">
                            <th scope="col">ID</th>
                            <th scope="col">Produk</th>
                            <th scope="col">Foto</th>
                            <th scope="col">Status</th>
                            <th scope="col">Harga</th>
                            <th scope="col">Jumlah Pesanan</th>
                            <th scope="col">Total</th>
                            <th scope="col">Batalkan Produk</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orderproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($rs->product->id); ?></th>
                            <td><?php echo e($rs->product->title); ?></td>
                            <td>
                                <?php if($rs->product->image): ?>
                                <img src="<?php echo e(Storage::url($rs->product->image)); ?>" style="height:50px ;width:50px; border-radius:2px">
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($rs->status); ?></td>
                            <td>Rp. <?php echo e(number_format($rs->product->price, 2)); ?></td>
                            <td><?php echo e($rs->quantity); ?> unit</td>
                            <td>Rp. <?php echo e(number_format($rs->amount, 2)); ?></td>
                            <td><a style="color: black;" class="icon_close" href="<?php echo e(route('userpanel.deleteproduct',['id'=>$rs->id])); ?>" , onclick="return confirm('Yakin ingin membatalkan?')"></a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php
                ($order->total =0)
                ?>
                <?php $__currentLoopData = $orderproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                ($order->total += $rs->quantity * $rs->price)
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="shoping__checkout">
                    <h5>Total Pesanan</h5>
                    <ul>
                        <li>Total Harga <span>Rp. <?php echo e(number_format($order->total, 2)); ?></span></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Bagian Blog Selesai -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelMarket\PoltekMart\resources\views/home/user/orderdetail.blade.php ENDPATH**/ ?>