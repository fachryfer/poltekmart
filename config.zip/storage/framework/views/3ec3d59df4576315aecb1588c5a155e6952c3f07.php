    <!-- Footer Section Begin -->
    <footer class="footer spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="footer__about">
                        <div class="footer__about__logo">
                            <a href="./index.html"><img src="<?php echo e(asset('assets')); ?>/img/poltekmartlogo.png" alt=""></a>
                        </div>
                        <ul>
                            <?php if($setting): ?>
                                <li>Alamat: <?php echo e($setting->adress); ?></li>
                                <li>Telepon: <?php echo e($setting->phone); ?></li>
                                <li>Email: <?php echo e($setting->email); ?></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 offset-lg-1">
                    <div class="footer__widget">
                        <h6>Halaman Kami</h6>
                        <ul>
                            <li><a href="<?php echo e(route('home')); ?>">Beranda</a></li>
                            <li><a href="<?php echo e(route('about')); ?>">Tentang Kami</a></li>
                            <li><a href="<?php echo e(route('contact')); ?>">Hubungi Kami</a></li>
                            <li><a href="<?php echo e(route('faq')); ?>">FAQ</a></li>
                        </ul>
                        <ul>
                            <li><a href="/loginuser">Masuk Anggota</a></li>
                            <li><a href="/registeruser">Daftar Anggota</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12">
                    <div class="footer__widget">
                        <h6>Daftar Anggota Sekarang</h6>
                        <a class="site-btn" href="/registeruser">Daftar Anggota</a>
                        <hr class="footer__copyright">
                        <div class="footer__widget__social">
                            <?php if($setting): ?>
                                <a href="<?php echo e($setting->facebook); ?>"><i class="fa fa-facebook"></i></a>
                                <a href="<?php echo e($setting->instagram); ?>"><i class="fa fa-instagram"></i></a>
                                <a href="<?php echo e($setting->twitter); ?>"><i class="fa fa-github"></i></a>
                                <a href="<?php echo e($setting->youtube); ?>"><i class="fa fa-youtube"></i></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer__copyright">
                        <div class="footer__copyright__text">
                            <p>
                                ©<script>
                                    document.write(new Date().getFullYear());
                                </script> PoltekMart | All Rights Reserved.
                            </p>
                        </div>
                        <div class="footer__copyright__payment"><img src="img/payment-item.png" alt=""></div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="<?php echo e(asset('assets')); ?>/js/jquery-3.3.1.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/jquery.nice-select.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/jquery-ui.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/jquery.slicknav.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/mixitup.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/owl.carousel.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/main.js"></script>
<?php /**PATH C:\xampp\htdocs\LaravelMarket\PoltekMart\resources\views/home/footer.blade.php ENDPATH**/ ?>