

<?php $__env->startSection('title', optional($setting)->title); ?>
<?php $__env->startSection('description', optional($setting)->description); ?>
<?php $__env->startSection('keywords', optional($setting)->keywords); ?>
<?php $__env->startSection('icon', Storage::url(optional($setting)->icon)); ?>

<?php $__env->startSection('content'); ?>
<section class="breadcrumb-section set-bg" data-setbg="<?php echo e(asset('assets')); ?>/img/colorcard.png">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2>MASUK ANGGOTA</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Blog Details Hero End -->

<div class="container">
    <div class="row">
        <div class="col-lg-12 col-md-7 order-md-1 order-1">
            <?php echo $__env->make('auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelMarket\POLTEKMART YANG PALING BARU DARI YANG PALING BARU\PoltekMart\resources\views/home/login.blade.php ENDPATH**/ ?>