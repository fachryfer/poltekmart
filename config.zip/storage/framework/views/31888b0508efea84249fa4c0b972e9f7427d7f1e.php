

<?php $__env->startSection('title', 'POLTEKMART | ADMIN PANEL'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content-inner">
    <!-- area row start -->
    <div class="row">
        <div class="col-lg-12 col-ml-12">
            <div class="row">
                <!-- start table form -->
                <div class="col-lg-12 mt-5">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">Detail Produk</h4>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <tr>
                                            <th scope="col">ID</th>
                                            <td><?php echo e($data->id); ?></td>
                                        </tr>
                                        <th style="width: 30px">Kategori</th>
                                        <td>
                                            <?php echo e(\App\Http\Controllers\AdminPanel\CategoryController::getParentsTree($data->category, $data->category->title)); ?>

                                        </td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Judul</th>
                                            <td><?php echo e($data->title); ?></td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Kata Kunci</th>
                                            <td><?php echo e($data->keywords); ?></td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Deskripsi</th>
                                            <td><?php echo e($data->description); ?></td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Detail</th>
                                            <td><?php echo $data->detail; ?></td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Harga</th>
                                            <td><?php echo e($data->price); ?></td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Stok</th>
                                            <td><?php echo e($data->quantity); ?></td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Pajak</th>
                                            <td>%<?php echo e($data->tax); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Foto</th>
                                            <td>
                                                <?php if($data->image): ?>
                                                <img src="<?php echo e(Storage::url($data->image)); ?>" style="height:150px ;width:150px; border-radius:2px">
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Tanggal Dibuat</th>
                                            <td><?php echo e($data->created_at); ?></td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Tanggal Terakhir Diperbarui</th>
                                            <td><?php echo e($data->updated_at); ?></td>
                                        </tr>
                                    </table>
                                    <a class="btn btn-warning" style="color: white;" href="<?php echo e(route('admin.product.edit',['id'=>$data->id])); ?>">Edit</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end table form -->
            </div>
        </div>
    </div>
    <!-- end area row -->
    <div class="row mt-5">
    </div>
    <!-- start area row -->
</div>
</div>
<!-- end main content area -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PoltekMart\resources\views/admin/product/show.blade.php ENDPATH**/ ?>