

<?php $__env->startSection('title', 'Detail Pesanan'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content-inner">
    <!-- Memulai area baris -->
    <div class="row">
        <div class="col-lg-12 col-ml-12">
            <div class="row">
                <!-- Memulai formulir tabel -->
                <div class="col-lg-12 mt-5">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">Detail Pesanan</h4>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <tr>
                                            <th style="width: 30px">Id</th>
                                            <td><?php echo e($data->id); ?></td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Nama Lengkap</th>
                                            <td><?php echo e($data->user->name); ?></td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Telepon</th>
                                            <td><?php echo e($data->phone); ?></td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Alamat</th>
                                            <td><?php echo e($data->address); ?></td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Total</th>
                                            <td>Rp. <?php echo e(number_format($data->total, 2)); ?></td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Tanggal Dibuat</th>
                                            <td><?php echo e($data->created_at); ?></td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Tanggal Terakhir Diperbarui</th>
                                            <td><?php echo e($data->updated_at); ?></td>
                                        </tr>
                                        <tr>
                                            <th style="width: 30px">Status:</th>
                                            <td>
                                                <form role="form" action="<?php echo e(route('admin.order.update', ['id' => $data->id])); ?>" method="POST" class="forms-sample">
                                                    <?php echo csrf_field(); ?>
                                                    <select name="status">
                                                        <option selected><?php echo e($data->status); ?></option>
                                                        <option>Baru</option>
                                                        <option>Dikonfirmasi</option>
                                                        <option>Selesai</option>
                                                        <option>Ditolak</option>
                                                    </select>
                                                    <br>
                                                    <select name="pembayaran">
                                                        <option value="Unpaid" <?php echo e($data->pembayaran == 'Unpaid' ? 'selected' : ''); ?>>Unpaid</option>
                                                        <option value="Paid" <?php echo e($data->pembayaran == 'Paid' ? 'selected' : ''); ?>>Paid</option>
                                                    </select>
                                                    <br>
                                                    <textarea name="note" cols="40" rows="2"><?php echo e($data->note); ?>

                                                    </textarea>
                                                    <div class="card-footer">
                                                        <button type="submit" class="btn-warning">Perbarui Status</button>
                                                    </div>
                                                </form>
                                            </td>
                                        </tr>
                                    </table>
                                    <table class="table text-center">
                                        <thead class="text-uppercase bg-warning">
                                            <tr class="text-white">
                                                <th scope="col">ID</th>
                                                <th scope="col">Produk</th>
                                                <th scope="col">Foto</th>
                                                <th scope="col">Biaya</th>
                                                <th scope="col">Jumlah Pesanan</th>
                                                <th scope="col">Total</th>
                                                <th scope="col">Status</th>
                                                <th scope="col">Pembayaran</th>
                                                <th scope="col">Setujui Produk</th>
                                                <th scope="col">Batalkan Produk</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $datalist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($rs->product->id); ?></th>
                                                <td><?php echo e($rs->product->title); ?></td>
                                                <td>
                                                    <?php if($rs->product->image): ?>
                                                    <img src="<?php echo e(Storage::url($rs->product->image)); ?>" style="height:50px ;width:50px; border-radius:2px">
                                                    <?php endif; ?>
                                                </td>
                                                <td>Rp. <?php echo e($rs->product->price); ?></td>
                                                <td><?php echo e($rs->quantity); ?> unit</td>
                                                <td>Rp. <?php echo e($rs->amount); ?></td>
                                                <td><?php echo e($rs->status); ?></td>
                                                <td><?php echo e($rs->pembayaran); ?></td>
                                                <td><a class="ti-check" href="<?php echo e(route('admin.order.acceptproduct',['id'=>$rs->id])); ?>" , onclick="return confirm('Anda yakin ingin menyetujui produk ini?')"></a></td>
                                                <td><a class="ti-trash" href="<?php echo e(route('admin.order.deleteproduct',['id'=>$rs->id])); ?>" , onclick="return confirm('Anda yakin ingin membatalkan produk ini?')"></a></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <?php
                                    ($data->total =0)
                                    ?>
                                    <?php $__currentLoopData = $datalist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    ($data->total += $rs->quantity * $rs->price)
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-6 col-ml-6">
                                        <div class="shoping__checkout">
                                            <h5>Total Keranjang</h5>
                                            <ul>
                                                <li>Total Tagihan <span>Rp. <?php echo e(number_format($data->total, 2)); ?></span></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Akhir formulir tabel -->
            </div>
        </div>
    </div>
    <!-- Akhir area baris -->
    <div class="row mt-5">
    </div>
    <!-- Memulai area baris -->
</div>
</div>
<!-- Akhir area konten utama -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PoltekMart\resources\views/admin/order/show.blade.php ENDPATH**/ ?>