

<?php $__env->startSection('title', 'Halaman Pesanan'); ?>
<?php $__env->startSection('description', optional($setting)->description); ?>
<?php $__env->startSection('keywords', optional($setting)->keywords); ?>
<?php $__env->startSection('icon', Storage::url(optional($setting)->icon)); ?>

<?php $__env->startSection('content'); ?>
<section class="breadcrumb-section set-bg" data-setbg="<?php echo e(asset('assets')); ?>/img/colorcard.png">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2>Pembayaran</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Bagian Selesai Breadcrumb -->

<!-- Bagian Checkout Mulai -->
<section class="checkout spad">
    <div class="container">
        <div class="checkout__form">
            <h4>Detail Pesanan</h4>
            <form action="<?php echo e(route('shopcart.storeorder')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="checkout__order">
                            <h4>Pesanan Anda</h4>
                            <div class="checkout__order__detail"><div class="checkout__order__products">Data Customer <span>Harga</span></div>
                                <p><?php echo e(Auth::user()->name); ?></p>
                                <p><?php echo e(Auth::user()->email); ?></p>
                                <p><?php echo e(session('order_data.phone', '')); ?></p>
                                <p><?php echo e(session('order_data.address', '')); ?></p>
                            </div>
                            <hr>
                            <div class="checkout__order__products">Produk &amp; Jumlah</div>
                            <ul>
                                <?php $__currentLoopData = $datalist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($rs->product->title); ?> x <?php echo e($rs->quantity); ?><span>Rp. <?php echo e(number_format($rs->product->price, 2)); ?></span></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <div class="checkout__order__subtotal">Subtotal <span>Rp.  <?php echo e(number_format($total, 2)); ?></span></div>
                            <div class="checkout__order__total">Total Pesanan <span>Rp.  <?php echo e(number_format($total, 2)); ?></span></div>
                            <button type="submit" class="site-btn" id="pay-button">KONFIRMASI &amp; BAYAR PESANAN</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>
<!-- Bagian Checkout Selesai -->

<?php if(session('error')): ?>
    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>

<?php if(isset($snapToken)): ?>
    <script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="<?php echo e(config('services.midtrans.client_key')); ?>"></script>
    <script>
    document.getElementById('pay-button').onclick = function(event){
        event.preventDefault(); // Mencegah form dari submit secara default
        console.log('Snap Token:', '<?php echo e($snapToken); ?>');
        snap.pay('<?php echo e($snapToken); ?>', {
            onSuccess: function(result){
                console.log('Payment success', result);
                // Anda bisa submit form secara manual di sini jika diperlukan
            },
            onPending: function(result){
                console.log('Payment pending', result);
            },
            onError: function(result){
                console.log('Payment error', result);
            }
        });
    };
    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.frontbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelMarket\POLTEKMART YANG PALING BARU DARI YANG PALING BARU\PoltekMart\resources\views/home/user/storeorder.blade.php ENDPATH**/ ?>