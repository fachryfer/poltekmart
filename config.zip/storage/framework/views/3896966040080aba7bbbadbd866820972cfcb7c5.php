

<?php $__env->startSection('title', 'Panel Admin Iz Market'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content-inner">
        <!-- area baris start -->
        <div class="row">
            <div class="col-lg-12 col-ml-12">
                <div class="row">
                    <!-- formulir tabel start -->
                    <div class="col-12 mt-5">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="header-title">Buat Kategori</h4>
                                <form role="form" action="<?php echo e(route('admin.category.store')); ?>" method="POST" enctype="multipart/form-data" class="forms-sample">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="">Kategori Induk</label>
                                        <select name="parent_id" class="form-control select2">
                                            <option value="0" selected="selected">Kategori Utama</option>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($rs->id); ?>"> <?php echo e(\App\Http\Controllers\AdminPanel\CategoryController::getParentsTree($rs, $rs->title)); ?> </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputName1">Judul</label>
                                        <input type="text" class="form-control" id="exampleInputName1" placeholder="Judul" name="title">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputName1">Kata Kunci</label>
                                        <input type="text" class="form-control" id="exampleInputName1" placeholder="Kata Kunci" name="keywords">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputName1">Deskripsi</label>
                                        <input type="Description" class="form-control" id="exampleInputName1" placeholder="Deskripsi" name="description">
                                    </div>
                                    <div class="form-group">
                                        <label>Unggah Foto</label>
                                        <div class="input-group col-xs-12">
                                            <label for="formFile" class="form-label"></label>
                                            <input class="form-control" type="file" name="image" id="image">
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-warning me-2">Buat</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- formulir tabel end -->
                </div>
            </div>
        </div>
        <!-- area baris end -->
        <div class="row mt-5">
        </div>
        <!-- area baris start-->
    </div>
    <!-- area konten utama end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PoltekMart\resources\views/admin/category/create.blade.php ENDPATH**/ ?>