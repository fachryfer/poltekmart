

<?php $__env->startSection('title', 'POLTEKMART | ADMIN PANEL'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content-inner">
    <!-- area baris dimulai -->
    <div class="row">
        <div class="col-lg-12 col-ml-12">
            <div class="row">
                <!-- formulir tabel dimulai -->
                <div class="col-lg-12 mt-5">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">Baris yang Dapat Diarahkan</h4>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <tr>
                                            <th scope="col">ID</th>
                                            <td><?php echo e($data->id); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Kategori Induk</th>
                                            <td><?php echo e(\App\Http\Controllers\AdminPanel\CategoryController::getParentsTree($data, $data->title)); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Judul</th>
                                            <td><?php echo e($data->title); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Kata Kunci</th>
                                            <td><?php echo e($data->keywords); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Deskripsi</th>
                                            <td><?php echo e($data->description); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Foto</th>
                                            <td>
                                                <?php if($data->image): ?>
                                                <img src="<?php echo e(Storage::url($data->image)); ?>" style="height:150px ;width:150px; border-radius:2px">
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Tanggal Pembuatan</th>
                                            <td><?php echo e($data->created_at); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="col">Tanggal Pembaharuan Terakhir</th>
                                            <td><?php echo e($data->updated_at); ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- formulir tabel berakhir -->
            </div>
        </div>
    </div>
    <!-- area baris berakhir -->
    <div class="row mt-5">
    </div>
    <!-- area baris dimulai-->
</div>
</div>
<!-- area konten utama berakhir -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PoltekMart\resources\views/admin/category/show.blade.php ENDPATH**/ ?>