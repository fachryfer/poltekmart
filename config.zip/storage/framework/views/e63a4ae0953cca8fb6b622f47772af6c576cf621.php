<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>POLTEKMART | ADMIN PANEL</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets')); ?>/admin/images/icon/fachryhotellogo2.png">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/admin/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/admin/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/admin/css/themify-icons.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/admin/css/metisMenu.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/admin/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/admin/css/slicknav.min.css">
    <!-- amchart css -->
    <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
    <!-- others css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/admin/assets/css/typography.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/admin/css/default-css.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/admin/css/styles.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/admin/css/responsive.css">
    <!-- modernizr css -->
    <script src="<?php echo e(asset('assets')); ?>/admin/js/vendor/modernizr-2.8.3.min.js"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/34.0.0/classic/ckeditor.js"></script>
</head>
<body>
    <!-- preloader area start -->
    <div id="preloader">
    <div class="loader"></div>
    </div>
    <!-- preloader area end -->
    <!-- page container area start -->
    <div class="page-container">
<?php echo $__env->make("admin.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make("admin.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make("admin.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\LaravelMarket\POLTEKMART YANG PALING BARU DARI YANG PALING BARU\PoltekMart\resources\views/layouts/adminbase.blade.php ENDPATH**/ ?>