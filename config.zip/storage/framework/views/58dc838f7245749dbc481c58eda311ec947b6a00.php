

<?php $__env->startSection('title', optional($setting)->title); ?>
<?php $__env->startSection('description', optional($setting)->description); ?>
<?php $__env->startSection('keywords', optional($setting)->keywords); ?>
<?php $__env->startSection('icon', Storage::url(optional($setting)->icon)); ?>

<?php $__env->startSection('content'); ?>
<!-- Bagian Pahlawan Detail Blog Mulai -->
<section class="breadcrumb-section set-bg" data-setbg="<?php echo e(asset('assets')); ?>/img/colorcard.png">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2>Pertanyaan Yang Sering Diajukan</h2>
                    <div class="breadcrumb__option">
                        <a href="<?php echo e(route('home')); ?>">Beranda </a>
                        <a href="<?php echo e(route('faq')); ?>">Pertanyaan Yang Sering Diajukan </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Bagian Pahlawan Detail Blog Selesai -->
<!-- FAQ mulai -->
<section class="blog-details spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-5 order-md-1 order-2">
                <div class="blog__sidebar">
                    <div class="blog__sidebar__item">
                        <h4>Terakhir Ditambahkan FAQ</h4>
                        <div class="blog__sidebar__recent">
                            <?php $__currentLoopData = $lastfaqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="blog__sidebar__recent__item">
                                <div class="blog__sidebar__recent__item__text">
                                    <h6><?php echo e($rs->question); ?></h6>
                                    <span><?php echo e($rs->created_at); ?></span>
                                </div>
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 col-md-7 order-md-1 order-1">
                <div class="blog__details__text">
                    <img src="<?php echo e(asset('assets')); ?>/img/blog/faq.png" alt="">
                    <?php $__currentLoopData = $datalist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h3><?php echo e($rs->question); ?></h3>
                    <p><?php echo $rs->answer; ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="blog__details__content">
                    <div class="row">
                        
                        <div class="col-lg-6">
                            <div class="blog__details__widget">
                                <div class="blog__details__social">
                                <?php if($setting): ?>
                                <a href="<?php echo e($setting->facebook); ?>"><i class="fa fa-facebook"></i></a>
                                <a href="<?php echo e($setting->instagram); ?>"><i class="fa fa-instagram"></i></a>
                                <a href="<?php echo e($setting->twitter); ?>"><i class="fa fa-github"></i></a>
                                <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Bagian Pahlawan Detail Blog Selesai -->
<!-- FAQ selesai -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelMarket\POLTEKMART YANG PALING BARU DARI YANG PALING BARU\PoltekMart\resources\views/home/faq.blade.php ENDPATH**/ ?>