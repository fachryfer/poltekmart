

<?php $__env->startSection('title', optional($setting)->title); ?>
<?php $__env->startSection('description', optional($setting)->description); ?>
<?php $__env->startSection('keywords', optional($setting)->keywords); ?>
<?php $__env->startSection('icon', Storage::url(optional($setting)->icon)); ?>


<?php $__env->startSection('content'); ?>
<!-- Bagian Breadcrumb Start -->
<section class="breadcrumb-section set-bg" data-setbg="<?php echo e(asset('assets')); ?>/img/colorcard.png">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2><?php echo e($data->title); ?></h2>
                    <div class="breadcrumb__option">
                        <a href="<?php echo e(route('home')); ?>">Beranda </a>
                        <a href="./index.html"><?php echo e($data->category->title); ?> </a>
                        <span><?php echo e($data->title); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Bagian Breadcrumb End -->

<section class="product-details spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="product__details__pic">
                    <div class="product__details__pic__item">
                        <img style="height: 550px;" class="product__details__pic__item--large" src="<?php echo e(Storage::url($data->image)); ?>">
                    </div>
                    <div class=" product__details__pic__slider owl-carousel">
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img data-imgbigurl="<?php echo e(Storage::url($rs->image)); ?>" src="<?php echo e(Storage::url($rs->image)); ?>" alt="">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="product__details__text">
                    <h3><?php echo e($data->title); ?></h3>
                    <?php
                    $average = $data->comment->average('rate');
                    ?>
                    <div class="product__details__rating">
                        <i <?php if($average==0): ?> class="fa fa-star-o" <?php endif; ?>></i>
                        <i <?php if($average>1 or $average==1): ?> class="fa fa-star" <?php endif; ?>></i>
                        <i <?php if($average>2 or $average==2): ?> class="fa fa-star" <?php endif; ?>
                            <?php if($average<2): ?> class="fa fa-star-o" <?php endif; ?>></i>
                        <i <?php if($average>3 or $average==3): ?> class="fa fa-star" <?php endif; ?>
                            <?php if($average<3): ?> class="fa fa-star-o" <?php endif; ?>></i>
                        <i <?php if($average>4 or $average==4): ?> class="fa fa-star" <?php endif; ?>
                            <?php if($average<4): ?> class="fa fa-star-o" <?php endif; ?>></i>
                        <i <?php if($average>5 or $average==5): ?> class="fa fa-star" <?php endif; ?>
                            <?php if($average<5): ?> class="fa fa-star-o" <?php endif; ?>></i>
                        <span>(<?php echo e($data->comment->count('id')); ?>)</span>
                    </div>
                    <div class="product__details__price">Rp. <?php echo e(number_format($data->price, 2)); ?></div>
                    <p><?php echo e($data->description); ?></p>
                    <?php echo $__env->make('home.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form action="<?php echo e(route('shopcart.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="product__details__quantity">
                            <div class="quantity">
                                <div class="pro-qty">
                                    <input type="number" name="quantity" value="1" min="1" max="<?php echo e($data->quantity); ?>">
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="product_id" value="<?php echo e($data->id); ?>">
                        <div style="display: flex">
                            <button class="primary-btn" type="submit">TAMBAHKAN KE KERANJANG</button>
                            <a class="primary-btn" href="https://api.whatsapp.com/send?phone=6285275194592" target="_blank" style="border: 2px solid #000;">
                                PESAN LEWAT WHATSAPP<i class="fa fa-whatsapp"></i>
                            </a>
                        </div>
                    </form>
                    <a href="<?php echo e(route('storefavorite',['id'=>$data->id])); ?>" class="heart-icon"><span class="icon_heart_alt"></span></a>
                    <ul>
                        <li><b>Stok</b> <span><?php echo e($data->quantity); ?></span></li>
                        <li><b>Bagikan</b>
                            <div class="share">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-instagram"></i></a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="product__details__tab">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle="tab" href="#tabs-1" role="tab" aria-selected="true">Detail Produk</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="tab" href="#tabs-3" role="tab" aria-selected="false">Ulasan <span>(<?php echo e($data->comment->count('id')); ?>)</span></a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="tabs-1" role="tabpanel">
                            <div class="product__details__tab__desc">
                                <h6>Detail Produk</h6>
                                <p><?php echo $data->detail; ?></p>
                            </div>
                        </div>
                        <div class="tab-pane" id="tabs-3" role="tabpanel">
                            <div class="product__details__tab__desc">
                                <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="container">
                                    <div class="row gy-5">
                                        <div class="col-6">
                                            <div class="p-3">
                                                <div><a href="#"><?php echo e($rs->user->name); ?></a></div>
                                                <div class="product__details__rating">
                                                    <i <?php if($rs->rate>=1): ?> class="fa fa-star" <?php endif; ?>
                                                        ></i>
                                                    <i <?php if($rs->rate>=2): ?> class="fa fa-star" <?php endif; ?>
                                                        <?php if($rs->rate<2): ?> class="fa fa-star-o" <?php endif; ?>></i>
                                                    <i <?php if($rs->rate>=3): ?> class="fa fa-star" <?php endif; ?>
                                                        <?php if($rs->rate<3): ?> class="fa fa-star-o" <?php endif; ?>></i>
                                                    <i <?php if($rs->rate>=4): ?> class="fa fa-star" <?php endif; ?>
                                                        <?php if($rs->rate<4): ?> class="fa fa-star-o" <?php endif; ?>></i>
                                                    <i <?php if($rs->rate>=5): ?> class="fa fa-star" <?php endif; ?>
                                                        <?php if($rs->rate<5): ?> class="fa fa-star-o" <?php endif; ?>></i>
                                                </div>
                                                <h5><?php echo e($rs->subject); ?></h5>
                                                <p><?php echo e($rs->comment); ?></p>
                                                <div><?php echo e($rs->created_at); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Bagian Detail Produk End -->

<!-- Bagian Produk Terkait Start -->
<div class="contact-form spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="contact__form__title">
                    <h2>Tambahkan Ulasan</h2>
                </div>
            </div>
        </div>
        <form action="<?php echo e(route('storecomment')); ?>" method="post" id="review_form" class="review_form">
            <?php echo csrf_field(); ?>
            <div class="row">
                <input type="hidden" class="input" name="product_id" value="<?php echo e($data->id); ?>" />
                <div class="col-lg-6 col-md-6">
                    <input name="subject" type="text" placeholder="Judul Ulasan">
                </div>
                <div class="col-lg-6 col-md-6">
                    <input name="rate" min="1" max="5" type="number" placeholder="Penilaian">
                </div>
                <div class="col-lg-12 text-center">
                    <textarea class="review_form_text" name="comment" placeholder="Ulasan Anda"></textarea>
                    <button type="submit" class="site-btn">KIRIM ULASAN</button>
                </div>
            </div>
        </form>
        <?php echo $__env->make('home.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PoltekMart\resources\views/home/product.blade.php ENDPATH**/ ?>