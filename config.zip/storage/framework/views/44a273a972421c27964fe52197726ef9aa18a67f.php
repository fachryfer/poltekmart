<!-- Preloader -->
<div id="preloder">
    <div class="loader"></div>
</div>

<!-- Humberger Begin -->
<div class="humberger__menu__overlay"></div>
<div class="humberger__menu__wrapper">
    <div class="humberger__menu__logo">
        <a href="#"><img src="<?php echo e(asset('assets')); ?>/img/poltekmartlogo.png" alt=""></a>
    </div>
    <div class="humberger__menu__cart">
        <?php if(auth()->guard()->check()): ?>
        <div class="col-lg-3">
            <div class="header__cart">
                <ul>
                    <li><a href="<?php echo e(route('userpanel.favoriteproduct')); ?>"><i class="fa fa-heart"></i> <span><?php echo e($favproducts->count()); ?></span></a></li>
                    <li><a href="<?php echo e(route('shopcart.index')); ?>"><i class="fa fa-shopping-bag"></i> <span></span></a></li>
                </ul>
                <?php
                ($total =0)
                ?>
                <?php $__currentLoopData = $shopcarttotal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                ($total += $rs->product->price * $rs->quantity)
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="header__cart__price">Total Keranjang: <span>Rp. <?php echo e(number_format($total, 2)); ?></span></div>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <div class="humberger__menu__widget">
        <div class="header__top__right__auth">
            <a href="loginuser"><i class="fa fa-user"></i> Masuk Anggota</a>
        </div>
    </div>
    <nav class="humberger__menu__nav mobile-menu">
        <ul>
            <li><a href="<?php echo e(route('home')); ?>">BERANDA</a></li>
            <li><a href="<?php echo e(route('categoryproducts', ['id' => 1])); ?>">BELANJA</a></li>
            <li><a href="<?php echo e(route('contact')); ?>">HUBUNGI KAMI</a></li>
            <li><a href="<?php echo e(route('about')); ?>">TENTANG KAMI</a></li>
            <li><a href="<?php echo e(route('faq')); ?>">PERTANYAAN UMUM</a></li>
            <li><a href="<?php echo e(route('userpanel.index')); ?>">AKUN SAYA</a>
                <ul class="header__menu__dropdown">
                    <li> <?php if(auth()->guard()->guest()): ?>
                        <a href="/loginuser">Masuk Anggota</a>
                    </li>
                    <li>
                        <a href="/registeruser">Daftar Anggota</a>
                        <?php endif; ?>
                    </li>
                    <li> <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(route('userpanel.index')); ?>"><?php echo e(Auth::user()->name); ?></a>
                        <?php endif; ?>
                    </li>
                    <li> <?php if(auth()->guard()->check()): ?>
                        <a href="/logoutuser">Keluar</a>
                        <?php endif; ?>
                    </li>
                </ul>
            </li>
        </ul>
    </nav>
    <div id="mobile-menu-wrap"></div>
    <div class="header__top__right__social">
        <?php if($setting): ?>
        <a href="<?php echo e($setting->facebook); ?>"><i class="fa fa-facebook"></i></a>
        <a href="<?php echo e($setting->instagram); ?>"><i class="fa fa-instagram"></i></a>
        <a href="<?php echo e($setting->twitter); ?>"><i class="fa fa-github"></i></a>
        <a href="<?php echo e($setting->youtube); ?>"><i class="fa fa-youtube"></i></a>
        <?php endif; ?>
    </div>
</div>
<!-- Humberger End -->

<!-- Header Section Begin -->
<header class="header">
    <div class="header__top">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="header__top__left">
                        
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="header__top__right">
                        <div class="header__top__right__social">
                            <?php if($setting): ?>
                            <a href="<?php echo e($setting->facebook); ?>"><i class="fa fa-facebook"></i></a>
                            <a href="<?php echo e($setting->instagram); ?>"><i class="fa fa-instagram"></i></a>
                            <a href="<?php echo e($setting->twitter); ?>"><i class="fa fa-github"></i></a>
                            <a href="<?php echo e($setting->youtube); ?>"><i class="fa fa-youtube"></i></a>
                            <?php endif; ?>
                        </div>
                        <div class="header__top__right__auth">
                            <a href="/loginuser"><i class="fa fa-user"></i> Login</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="header__logo">
                    <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('assets')); ?>/img/poltekmartlogo.png" alt=""></a>
                </div>
            </div>
            <div class="col-lg-6">
                <nav class="header__menu">
                    <ul>
                        <li><a href="<?php echo e(route('home')); ?>">BERANDA</a></li>
                        <li><a href="<?php echo e(route('categoryproducts', ['id' => 1])); ?>">BELANJA</a></li>
                        <li><a href="<?php echo e(route('contact')); ?>">HUBUNGI KAMI</a></li>
                        <li><a href="<?php echo e(route('about')); ?>">TENTANG KAMI</a></li>
                        <li><a href="<?php echo e(route('faq')); ?>">PERTANYAAN UMUM</a></li>
                        <li><a href="<?php echo e(route('userpanel.index')); ?>">AKUN SAYA</a>
                            <ul class="header__menu__dropdown">
                                <li> <?php if(auth()->guard()->guest()): ?>
                                    <a href="/loginuser">Masuk Anggota</a>
                                </li>
                                <li>
                                    <a href="/registeruser">Daftar Anggota</a>
                                    <?php endif; ?>
                                </li>
                                <li> <?php if(auth()->guard()->check()): ?>
                                    <a href="<?php echo e(route('userpanel.index')); ?>"><?php echo e(Auth::user()->name); ?></a>
                                    <?php endif; ?>
                                </li>
                                <li> <?php if(auth()->guard()->check()): ?>
                                    <a href="/logoutuser">Keluar</a>
                                    <?php endif; ?>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
            <?php if(auth()->guard()->check()): ?>
            <div class="col-lg-3">
                <div class="header__cart">
                    <ul>
                        <li><a href="<?php echo e(route('userpanel.favoriteproduct')); ?>"><i class="fa fa-heart"></i> <span><?php echo e($favproducts->count()); ?></span></a></li>
                        <li><a href="<?php echo e(route('shopcart.index')); ?>"><i class="fa fa-shopping-bag"></i></a></li>
                    </ul>
                    <?php
                    ($total =0)
                    ?>
                    <?php $__currentLoopData = $shopcarttotal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    ($total += $rs->product->price * $rs->quantity)
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="header__cart__price">Total Keranjang: <span>Rp. <?php echo e(number_format($total, 2)); ?></span></div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <div class="humberger__open">
            <i class="fa fa-bars"></i>
        </div>
    </div>
</header>
<!-- Header Section End -->
<?php /**PATH C:\xampp\htdocs\LaravelMarket\POLTEKMART YANG PALING BARU DARI YANG PALING BARU\PoltekMart\resources\views/home/header.blade.php ENDPATH**/ ?>