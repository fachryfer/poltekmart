

<?php $__env->startSection('title', optional($setting)->title); ?>
<?php $__env->startSection('description', optional($setting)->description); ?>
<?php $__env->startSection('keywords', optional($setting)->keywords); ?>
<?php $__env->startSection('icon', Storage::url(optional($setting)->icon)); ?>

<?php $__env->startSection('content'); ?>
<!-- Bagian Hero Detail Blog Dimulai -->
<section class="breadcrumb-section set-bg" data-setbg="<?php echo e(asset('assets')); ?>/img/colorcard.png">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2>Tentang Kami</h2>
                    <div class="breadcrumb__option">
                        <a href="<?php echo e(route('home')); ?>">Beranda</a>
                        <a href="<?php echo e(route('about')); ?>">Tentang Kami</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Bagian Hero Detail Blog Selesai -->

<!-- Bagian Detail Blog Dimulai -->
<section class="blog-details spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-7 order-md-1 order-1">
                <div class="blog__details__text">
                    <img src="img/blog/details/details-pic.jpg" alt="">
                    <?php if($setting): ?>
                    <?php echo $setting->aboutus; ?>

                </div>
                <div class="blog__details__content">
                    <div class="row">
                        <div class="col-lg-6">
                            <?php echo $setting->references; ?>

                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Bagian Detail Blog Selesai -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelMarket\PoltekMart\resources\views/home/about.blade.php ENDPATH**/ ?>