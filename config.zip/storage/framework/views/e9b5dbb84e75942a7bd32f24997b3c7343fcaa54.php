

<?php $__env->startSection('title', 'Pesanan İz Market'); ?>

<?php $__env->startSection('content'); ?>
<div class="main-content-inner">
    <!-- area baris start -->
    <div class="row">
        <div class="col-lg-12 col-ml-12">
            <div class="row">
                <!-- formulir tabel start -->
                <div class="col-lg-12 mt-5">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">Pesanan</h4>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table class="table text-center">
                                        <thead class="text-uppercase bg-warning">
                                            <tr class="text-white">
                                                <th scope="col">ID</th>
                                                <th scope="col">Nama</th>
                                                <th scope="col">Telepon</th>
                                                <th scope="col">E-mail</th>
                                                <th scope="col">Alamat</th>
                                                <th scope="col">Catatan Admin</th>
                                                <th scope="col">Status</th>
                                                <th scope="col">Pembayaran</th>
                                                <th scope="col">Tampilkan Detail</th>
                                                <th scope="col">Hapus</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($rs->id); ?></th>
                                                <td><a href="<?php echo e(route('admin.user.show',['id'=>$rs->user_id])); ?>"><?php echo e($rs->user->name); ?></a></td>
                                                <td><?php echo e($rs->phone); ?></td>
                                                <td><?php echo e($rs->email); ?></td>
                                                <td><?php echo e($rs->address); ?></td>
                                                <td><?php echo e($rs->note); ?></td>
                                                <td><?php echo e($rs->status); ?></td>
                                                <td><?php echo e($rs->pembayaran); ?></td>
                                                <td><a class="ti-info-alt" href="<?php echo e(route('admin.order.show',['id'=>$rs->id])); ?>"></a></td>
                                                <td><a class="ti-trash" href="<?php echo e(route('admin.order.reject',['id'=>$rs->id])); ?>" , onclick="return confirm('Anda yakin ingin membatalkan pesanan ini?')"></a></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- formulir tabel end -->
            </div>
        </div>
    </div>
    <!-- area baris end -->
    <div class="row mt-5">
    </div>
    <!-- area baris start-->
</div>
</div>
<!-- area konten utama end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminbase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelMarket\PoltekMart\resources\views/admin/order/index.blade.php ENDPATH**/ ?>