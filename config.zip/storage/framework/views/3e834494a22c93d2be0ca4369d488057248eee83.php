<ul class="category__menu__dropdown">
<?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if(count($subcategory->children)): ?>
            <li class=""><?php echo e($subcategory->title); ?></li>
            <ul class="">
                <?php echo $__env->make('home.categorytree',[children => $subcategory->children], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </ul>
            <hr>
        <?php else: ?>
            <li><a href="<?php echo e(route('categoryproducts',['id'=>$subcategory->id])); ?>">-<?php echo e($subcategory->title); ?></a></li>
        <?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH C:\xampp\htdocs\LaravelMarket\PoltekMart\resources\views/home/categorytree.blade.php ENDPATH**/ ?>